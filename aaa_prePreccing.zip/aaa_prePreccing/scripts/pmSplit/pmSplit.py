import json
import traceback

from input_parser import parse_input_data




def main():
    try:
        pm = parse_input_data()
        print(pm)
    except Exception as e:
        error_message = {
            "error": (e),
            "trace": traceback.format_exc()
        }
        print(json.dumps(error_message))

if __name__ == "__main__":
    main()
