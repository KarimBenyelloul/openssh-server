import json
import sys
import os 

def parse_input_data():
    if len(sys.argv) > 1 and os.path.isfile(sys.argv[1]):
        # Running in test mode with two files: zones.json and config.json
        with open(sys.argv[1], "r") as f:
            config_data = json.load(f)
        pool_members = config_data.get("pool_members")
        origin_bdfzone = config_data.get("origin_bdfzone")

    else:
        # Running in Terraform mode via stdin
        args = json.loads(sys.stdin.read())
        pool_members = json.loads(args.get("pool_members"))
        origin_bdfzone = json.loads(args.get("origin_bdfzone"))

    return pool_members, origin_bdfzone
