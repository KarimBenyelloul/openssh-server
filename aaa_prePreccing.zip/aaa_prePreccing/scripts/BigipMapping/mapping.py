import json
import traceback

from input_parser import parse_input_data
from bdfzones_utils import (
    find_environment_by_bdfzone_and_environment,
    extract_cluster,
    extract_gtm,
    extract_key_from_cluster
)
from failover_utils import extract_mgmtip_of_active_bigip_from_clusters


def stringify_output(output_dict):
    return {k: json.dumps(v) for k, v in output_dict.items()}

def format_output(exp_env, maia_env, fbi_env, origin_env, username, password):
    exposition_adc_cluster_0 = extract_cluster(exp_env, 0)
    exposition_adc_cluster_1 = extract_cluster(exp_env, 1)
    exposition_gtm_cluster = extract_gtm(exp_env)

    maia_adc_cluster_0 = extract_cluster(maia_env, 0)
    maia_adc_cluster_1 = extract_cluster(maia_env, 1)
    maia_gtm_cluster =  extract_gtm(maia_env)

    fbi_adc_cluster_0 = extract_cluster(fbi_env, 0)
    fbi_adc_cluster_1 = extract_cluster(fbi_env, 1)
    fbi_gtm_cluster = extract_gtm(fbi_env)

    origin_adc_cluster_0 = extract_cluster(origin_env, 0)
    origin_adc_cluster_1 = extract_cluster(origin_env, 1)
    origin_gtm_cluster = extract_gtm(origin_env)
    return {
        "has_exposition_env":  bool(exp_env),
        "has_maia_env": bool(maia_env),
        "has_fbi_env":  bool(fbi_env),
        "has_origin_env":  bool(origin_env),

        "exposition_adc_cluster_0": exposition_adc_cluster_0,
        "exposition_adc_cluster_0_mgmt_ip": extract_mgmtip_of_active_bigip_from_clusters(exposition_adc_cluster_0, username, password),
        "exposition_adc_cluster_0_vip_subnets": extract_key_from_cluster(exposition_adc_cluster_0,"vip_subnets"),
        "exposition_adc_cluster_0_snat_ips": extract_key_from_cluster(exposition_adc_cluster_0,"snat_ips"),
        
        "exposition_adc_cluster_1": exposition_adc_cluster_1,
        "exposition_adc_cluster_1_mgmt_ip": extract_mgmtip_of_active_bigip_from_clusters(exposition_adc_cluster_1, username, password),
        "exposition_adc_cluster_1_vip_subnets": extract_key_from_cluster(exposition_adc_cluster_1,"vip_subnets"),
        "exposition_adc_cluster_1_snat_ips": extract_key_from_cluster(exposition_adc_cluster_1,"snat_ips"),
        
        "exposition_gtm_cluster": exposition_gtm_cluster,
        "exposition_gtm_cluster_mgmt_ip": extract_mgmtip_of_active_bigip_from_clusters(exposition_gtm_cluster, username, password),
        "exposition_gtm_cluster_suffix_fqdn": extract_key_from_cluster(exposition_gtm_cluster,"suffix_fqdn"),



        "maia_adc_cluster_0": maia_adc_cluster_0,
        "maia_adc_cluster_0_mgmt_ip": extract_mgmtip_of_active_bigip_from_clusters(maia_adc_cluster_0, username, password),
        "maia_adc_cluster_0_vip_subnets": extract_key_from_cluster(maia_adc_cluster_0,"vip_subnets"),
        "maia_adc_cluster_0_snat_ips": extract_key_from_cluster(maia_adc_cluster_0,"snat_ips"),

        "maia_adc_cluster_1": maia_adc_cluster_1,
        "maia_adc_cluster_1_mgmt_ip": extract_mgmtip_of_active_bigip_from_clusters(maia_adc_cluster_1, username, password),
        "maia_adc_cluster_1_vip_subnets": extract_key_from_cluster(maia_adc_cluster_1,"vip_subnets"),
        "maia_adc_cluster_1_snat_ips": extract_key_from_cluster(maia_adc_cluster_1,"snat_ips"),
        
        "maia_gtm_cluster": maia_gtm_cluster,      
        "maia_gtm_cluster_mgmt_ip": extract_mgmtip_of_active_bigip_from_clusters(maia_gtm_cluster, username, password),
        "maia_gtm_cluster_suffix_fqdn": extract_key_from_cluster(maia_gtm_cluster,"suffix_fqdn"),   



        "fbi_adc_cluster_0": fbi_adc_cluster_0,
        "fbi_adc_cluster_0_mgmt_ip": extract_mgmtip_of_active_bigip_from_clusters(fbi_adc_cluster_0, username, password),
        "fbi_adc_cluster_0_vip_subnets": extract_key_from_cluster(fbi_adc_cluster_0,"vip_subnets"),
        "fbi_adc_cluster_0_snat_ips": extract_key_from_cluster(fbi_adc_cluster_0,"snat_ips"),

        "fbi_adc_cluster_1": fbi_adc_cluster_1,
        "fbi_adc_cluster_1_mgmt_ip": extract_mgmtip_of_active_bigip_from_clusters(fbi_adc_cluster_1, username, password),
        "fbi_adc_cluster_1_vip_subnets": extract_key_from_cluster(fbi_adc_cluster_1, "vip_subnets"),
        "fbi_adc_cluster_1_snat_ips": extract_key_from_cluster(fbi_adc_cluster_1, "snat_ips"),

        "fbi_gtm_cluster": fbi_gtm_cluster,
        "fbi_gtm_cluster_mgmt_ip": extract_mgmtip_of_active_bigip_from_clusters(fbi_gtm_cluster, username, password),
        "fbi_gtm_cluster_suffix_fqdn": extract_key_from_cluster(fbi_gtm_cluster,"suffix_fqdn"),   



        "origin_adc_cluster_0": origin_adc_cluster_0,
        "origin_adc_cluster_0_mgmt_ip": extract_mgmtip_of_active_bigip_from_clusters(origin_adc_cluster_0, username, password),
        "origin_adc_cluster_0_vip_subnets": extract_key_from_cluster(origin_adc_cluster_0,"vip_subnets"),
        "origin_adc_cluster_0_snat_ips": extract_key_from_cluster(origin_adc_cluster_0, "snat_ips"),
        
        "origin_adc_cluster_1": origin_adc_cluster_1,
        "origin_adc_cluster_1_mgmt_ip": extract_mgmtip_of_active_bigip_from_clusters(origin_adc_cluster_1, username, password),
        "origin_adc_cluster_1_vip_subnets": extract_key_from_cluster(origin_adc_cluster_1,"vip_subnets"),
        "origin_adc_cluster_1_snat_ips": extract_key_from_cluster(origin_adc_cluster_1, "snat_ips"),
        
        "origin_gtm_cluster": origin_gtm_cluster,
        "origin_gtm_cluster_mgmt_ip": extract_mgmtip_of_active_bigip_from_clusters(origin_gtm_cluster, username, password),
        "origin_gtm_cluster_suffix_fqdn": extract_key_from_cluster(origin_gtm_cluster,"suffix_fqdn"),   



        "exposition_env": exp_env,
        "maia_env": maia_env,
        "fbi_env": fbi_env,
        "origin_env": origin_env,
    }



def main():
    try:
        #initializing input values
        bdf_zones, environment, exposition, fbi, origin_bdfzone, username, password = parse_input_data()
        
        #initializing output values
        exp_zone_declaration = exp_env = maia_zone_declaration = maia_env = fbi_zone_declaration = fbi_env = origin_zone_declaration = origin_env = None

        if fbi:
            #Get FBI env
            fbi_zone_declaration, fbi_env = find_environment_by_bdfzone_and_environment(bdf_zones, "zsec_bdf", environment) 
            origin_zone_declaration, origin_env = find_environment_by_bdfzone_and_environment(bdf_zones, origin_bdfzone, environment) 
            
            #Get exposition env 
            if exposition:
                exp_zone_declaration, exp_env = find_environment_by_bdfzone_and_environment(bdf_zones, exposition, environment)
                if exposition=="zsec_internet":
                    maia_zone_declaration, maia_env = find_environment_by_bdfzone_and_environment(bdf_zones, "maia", environment)
                    
        else:
            if exposition:
                #Get exposition only
                exp_zone_declaration, exp_env = find_environment_by_bdfzone_and_environment(bdf_zones, exposition, environment)
                if exposition=="zsec_internet":
                    maia_zone_declaration, maia_env = find_environment_by_bdfzone_and_environment(bdf_zones, "maia", environment)
            else:
                #Get origin env
                origin_zone_declaration_declaration, origin_env  = find_environment_by_bdfzone_and_environment(bdf_zones, origin_bdfzone, environment) 

        # Prepare Terraform-compatible output
        output= format_output(exp_env, maia_env, fbi_env, origin_env, username, password)
        print (json.dumps(stringify_output(output)))

    except Exception as e:
        error_message = {
            "error": (e),
            "trace": traceback.format_exc()
        }
        print(json.dumps(error_message))

if __name__ == "__main__":
    main()
