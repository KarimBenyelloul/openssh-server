import json
import sys
import os 

def parse_input_data():
    """
    Determines the input source (test mode with 2 JSON files or stdin from Terraform),
    parses the values, and returns the decoded input data.

    Returns:
        Tuple of:
            - bdf_zones (list)
            - environment (str)
            - exposition (str or None)
            - fbi (bool)
            - origin_bdfzone (str)
            - username (str)
            - password (str)
    """
    if len(sys.argv) > 2 and os.path.isfile(sys.argv[1]) and os.path.isfile(sys.argv[2]):
        # Running in test mode with two files: zones.json and config.json
        with open(sys.argv[1], "r") as f:
            bdf_zones_data = json.load(f)
        with open(sys.argv[2], "r") as f:
            config_data = json.load(f)

        bdf_zones = bdf_zones_data["bdf_zones"]
        environment = config_data["environment"]
        exposition = config_data.get("exposition", None)
        fbi = config_data.get("fbi", False)
        origin_bdfzone = config_data["origin_bdfzone"]
        username = config_data.get("username", "admin")
        password = config_data.get("password", "admin")

    else:
        # Running in Terraform mode via stdin
        args = json.loads(sys.stdin.read())
        bdf_zones = json.loads(args["bdf_zones"])["bdf_zones"]
        environment = json.loads(args["environment"])
        exposition = json.loads(args.get("exposition", "null"))
        fbi = json.loads(args.get("fbi", "false"))
        origin_bdfzone = json.loads(args["origin_bdfzone"])
        username = json.loads(args.get("username", '"admin"'))
        password = json.loads(args.get("password", '"admin"'))

    return bdf_zones, environment, exposition, fbi, origin_bdfzone, username, password
