from requests.auth import HTTPBasicAuth
import requests
import sys
import json

# Disable SSL warnings
requests.packages.urllib3.disable_warnings()

# NOT USED, the function that returns active member is prefered 
def extract_mgmtip_of_first_bigip_from_clusters(clusters, username, password):
    try:
        if clusters and isinstance(clusters, dict):
            devices = clusters.get("devices", [])
            if devices and isinstance(devices, list):
                return devices[0].get("mgmt_ip", None)
        return None
    except Exception:
        return None



def get_failover_status(mgmt_ip, username, password):
    """
    Queries a BIG-IP device for its failover status.

    :param mgmt_ip: IP of the BIG-IP management interface
    :param username: admin username
    :param password: admin password
    :return: status string (e.g., 'ACTIVE', 'STANDBY', etc.) or None if failed
    """
    url = f"https://{mgmt_ip}/mgmt/tm/cm/failover-status"

    try:
        response = requests.get(
            url,
            auth=HTTPBasicAuth(username, password),
            verify=False,
            timeout=5
        )
        response.raise_for_status()
        data = response.json()

        return data.get('entries', {}) \
            .get('https://localhost/mgmt/tm/cm/failover-status/0', {}) \
            .get('nestedStats', {}) \
            .get('entries', {}) \
            .get('status', {}) \
            .get('description', None)

    except Exception as e:
        raise RuntimeError(f"Failed to get the failover status of BIG-IP {mgmt_ip} device")

def extract_mgmtip_of_active_bigip_from_clusters(clusters, username, password):
    """
    Identifies and returns the mgmt_ip of the active BIG-IP device from a cluster.

    :param clusters: Dict containing 'devices' key
    :param username: Admin username for BIG-IP API
    :param password: Admin password for BIG-IP API
    :return: mgmt_ip of active device or None
    """
    try:
        if not clusters or not isinstance(clusters, dict):
            return None

        devices = clusters.get("devices", [])
        if not devices or not isinstance(devices, list):
            return None

        for device in devices:
            mgmt_ip = device.get("mgmt_ip")
            if not mgmt_ip:
                continue
            status = get_failover_status(mgmt_ip, username, password)
            if status and status.lower() == "active":
                return mgmt_ip
        
        error = json.dumps({
            "error": f"None of the devices in {clusters} is in active state"
        })
        print(error)
        sys.exit(0)
    except Exception as e:
        raise RuntimeError(f"Failed to get active BIG-IP device in the cluster : {clusters}")
    