import sys
import json


def find_environment_by_bdfzone_and_environment(bdf_zones, bdfzone, environment):
    for zone in bdf_zones:
        if zone.get("bdf_zone", "") == bdfzone:
            for env in zone.get("environments", []):
                if env.get("environment", "") == environment:
                    return zone, env
    
    mapping_error = json.dumps({
            "error": f"No matching BDF zone/environment found for {bdfzone} zone in {environment} environment"
        })
    print(mapping_error)
    sys.exit(0)


def extract_cluster(env, index):
    """
    Safely extract adc_cluster from afs_zones[index] in the environment dict.
    Returns an empty dict if the path is missing or incomplete.
    """
    try:
        afs_zones = env.get("afs_zones", [])
        if len(afs_zones) > index:
            return afs_zones[index].get("adc_cluster", {})
        return None
    except Exception:
        return None

def extract_gtm(env):
    """
    Safely extract gtm_clusters from the environment dict.
    Returns an empty dict if missing.
    """
    try:
        return env.get("gtm_cluster", None) if env else None
    except Exception:
        return None


def extract_key_from_cluster(cluster, key):
    if not isinstance(cluster, dict):
        return None

    return cluster.get(key)